from darshellclock.main import init

def main():
    init()

main()
