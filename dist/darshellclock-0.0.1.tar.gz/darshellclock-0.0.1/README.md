# darshell-clock
ASCII rendering of time and date in console

Uses ncurses

Support 2 size of ASCII made blocky digit to support the smallest 

 - Hit "h" in the application to have help (these commands)
 - Hit "q" to quit

 - Hit "t" to change time color
 - Hit "d" to change date color
 - Hit "s" to hide the date
 
Done in 2021 by darokin
